<?php
/**
 * SMTP Configuration for Email Sending
 * 
 * IMPORTANT: Before using, you must:
 * 1. Enable 2-Factor Authentication on your Google account
 * 2. Generate an App Password: https://myaccount.google.com/apppasswords
 * 3. Replace 'YOUR_APP_PASSWORD_HERE' with the generated App Password
 */

// SMTP Server Configuration
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_SECURE', 'tls'); // Use 'tls' for port 587, 'ssl' for port 465

// SMTP Authentication
define('SMTP_USERNAME', 'anassakera@gmail.com');
define('SMTP_PASSWORD', 'zkyi bwhb sfrn ijuh'); // Replace with your Gmail App Password

// Email Sender Information
define('SMTP_FROM_EMAIL', 'anassakera@gmail.com');
define('SMTP_FROM_NAME', 'IDEA App');

// Application Configuration
define('APP_NAME', 'IDEA');
define('APP_URL', 'http://localhost'); // Update this to your actual URL

// Debug mode (set to false in production)
define('SMTP_DEBUG', false);

?>
