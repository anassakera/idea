# SMTP Email Setup Guide for IDEA App

## Prerequisites

1. **PHP 7.2+** with the following extensions:
   - `openssl` (for TLS/SSL)
   - `mbstring`

2. **Composer** (PHP package manager)

---

## Installation Steps

### 1. Install PHPMailer

Navigate to the API directory and run:

```bash
cd lib/idea_APIs
composer require phpmailer/phpmailer
```

> **Note**: If you don't have Composer installed, download it from [getcomposer.org](https://getcomposer.org/download/)

---

### 2. Configure Gmail App Password

Gmail requires an **App Password** to send emails via SMTP:

1. Go to [Google Account Settings](https://myaccount.google.com/)
2. Navigate to **Security** → **2-Step Verification** (enable if not already)
3. Go to **Security** → **App passwords**
4. Select **Mail** and your device
5. Click **Generate** and copy the 16-character password

---

### 3. Update SMTP Configuration

Edit `lib/idea_APIs/smtp_config.php`:

```php
// Replace with your Gmail App Password (16 characters, no spaces)
define('SMTP_PASSWORD', 'xxxx xxxx xxxx xxxx');
```

---

## Testing

### Method 1: Using the Flutter App

1. Start your local PHP server
2. Open the IDEA app
3. Go to **Forgot Password** screen
4. Enter a valid email address
5. Check the email inbox for the reset code

### Method 2: Using curl

```bash
curl -X POST http://localhost/idea_APIs/auth/forgot_password.php \
  -H "Content-Type: application/json" \
  -d '{"email": "your-email@example.com"}'
```

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| `PHPMailer is not installed` | Run `composer require phpmailer/phpmailer` |
| `SMTP connect() failed` | Check internet connection, verify App Password |
| `Authentication failed` | Regenerate App Password, ensure 2FA is enabled |
| Email lands in spam | Add sender to contacts, check SPF/DKIM settings |

---

## File Structure

```
lib/idea_APIs/
├── smtp_config.php      # SMTP settings (edit this)
├── mail_helper.php      # Email sending functions
├── vendor/              # Composer packages (auto-created)
└── auth/
    └── forgot_password.php
```

---

## Security Notes

- ⚠️ Never commit `smtp_config.php` with real passwords to version control
- Add to `.gitignore`:
  ```
  lib/idea_APIs/smtp_config.php
  lib/idea_APIs/vendor/
  ```
- Consider using environment variables in production
