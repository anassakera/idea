<?php
/**
 * Reset Password API Endpoint
 * Handles password reset using token
 */

require_once '../db_connect.php';

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respondWithError('Method not allowed. Use POST', 405);
}

// Get JSON input
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Validate required fields
$validation = validateRequiredFields($data, ['token', 'new_password']);
if ($validation !== true) {
    respondWithError($validation, 400);
}

$token = sanitizeInput($data['token']);
$newPassword = $data['new_password'];

// Validate password strength
if (strlen($newPassword) < 6) {
    respondWithError('Password must be at least 6 characters long', 400);
}

try {
    $pdo = getDbConnection();
    
    // Check if token is valid and not expired
    $stmt = $pdo->prepare("
        SELECT prt.id, prt.user_id, prt.is_used, prt.expires_at, u.email 
        FROM password_reset_tokens prt
        JOIN users u ON prt.user_id = u.id
        WHERE prt.token = :token
    ");
    $stmt->execute(['token' => $token]);
    $resetToken = $stmt->fetch();
    
    // Validate token
    if (!$resetToken) {
        respondWithError('Invalid reset token', 400);
    }
    
    if ($resetToken['is_used']) {
        respondWithError('Reset token has already been used', 400);
    }
    
    if (strtotime($resetToken['expires_at']) < time()) {
        respondWithError('Reset token has expired', 400);
    }
    
    // Update password
    $hashedPassword = hashPassword($newPassword);
    $updateStmt = $pdo->prepare("UPDATE users SET password = :password WHERE id = :user_id");
    $updateStmt->execute([
        'password' => $hashedPassword,
        'user_id' => $resetToken['user_id']
    ]);
    
    // Mark token as used
    $markUsedStmt = $pdo->prepare("UPDATE password_reset_tokens SET is_used = TRUE WHERE id = :id");
    $markUsedStmt->execute(['id' => $resetToken['id']]);
    
    // Invalidate all sessions for this user (force re-login)
    $invalidateSessionsStmt = $pdo->prepare("DELETE FROM user_sessions WHERE user_id = :user_id");
    $invalidateSessionsStmt->execute(['user_id' => $resetToken['user_id']]);
    
    respondWithSuccess([
        'message' => 'Password reset successfully. Please login with your new password'
    ], 200);
    
} catch (PDOException $e) {
    respondWithError('Failed to reset password: ' . $e->getMessage(), 500);
}

?>
