<?php
/**
 * Register API Endpoint
 * Handles user registration
 */

require_once '../db_connect.php';

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respondWithError('Method not allowed. Use POST', 405);
}

// Get JSON input
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Validate required fields
$validation = validateRequiredFields($data, ['full_name', 'email', 'password']);
if ($validation !== true) {
    respondWithError($validation, 400);
}

// Sanitize inputs
$fullName = sanitizeInput($data['full_name']);
$email = sanitizeInput($data['email']);
$password = $data['password'];
$phone = isset($data['phone']) ? sanitizeInput($data['phone']) : null;
$userType = isset($data['user_type']) ? sanitizeInput($data['user_type']) : 'student';

// Validate email format
if (!isValidEmail($email)) {
    respondWithError('Invalid email format', 400);
}

// Validate password strength (minimum 6 characters)
if (strlen($password) < 6) {
    respondWithError('Password must be at least 6 characters long', 400);
}

// Validate user type
$allowedUserTypes = ['student', 'parent', 'teacher', 'admin'];
if (!in_array($userType, $allowedUserTypes)) {
    respondWithError('Invalid user type', 400);
}

try {
    $pdo = getDbConnection();
    
    // Check if email already exists
    $checkStmt = $pdo->prepare("SELECT id FROM users WHERE email = :email");
    $checkStmt->execute(['email' => $email]);
    
    if ($checkStmt->fetch()) {
        respondWithError('Email already registered', 409);
    }
    
    // Hash password
    $hashedPassword = hashPassword($password);
    
    // Insert new user
    $stmt = $pdo->prepare("
        INSERT INTO users (full_name, email, password, phone, user_type) 
        VALUES (:full_name, :email, :password, :phone, :user_type)
    ");
    
    $stmt->execute([
        'full_name' => $fullName,
        'email' => $email,
        'password' => $hashedPassword,
        'phone' => $phone,
        'user_type' => $userType
    ]);
    
    $userId = $pdo->lastInsertId();
    
    // Generate session token
    $sessionToken = generateToken(32);
    $expiresAt = date('Y-m-d H:i:s', strtotime('+7 days'));
    
    // Create session
    $sessionStmt = $pdo->prepare("
        INSERT INTO user_sessions (user_id, session_token, ip_address, user_agent, expires_at) 
        VALUES (:user_id, :token, :ip, :user_agent, :expires_at)
    ");
    $sessionStmt->execute([
        'user_id' => $userId,
        'token' => $sessionToken,
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
        'expires_at' => $expiresAt
    ]);
    
    // Prepare response
    $response = [
        'user' => [
            'id' => $userId,
            'full_name' => $fullName,
            'email' => $email,
            'user_type' => $userType,
            'email_verified' => false
        ],
        'token' => $sessionToken,
        'expires_at' => $expiresAt
    ];
    
    respondWithSuccess($response, 201);
    
} catch (PDOException $e) {
    respondWithError('Registration failed: ' . $e->getMessage(), 500);
}

?>
