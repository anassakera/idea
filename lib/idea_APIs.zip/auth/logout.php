<?php
/**
 * Logout API Endpoint
 * Handles user logout by invalidating session
 */

require_once '../db_connect.php';

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respondWithError('Method not allowed. Use POST', 405);
}

// Get JSON input
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Validate required fields
$validation = validateRequiredFields($data, ['token']);
if ($validation !== true) {
    respondWithError($validation, 400);
}

$token = sanitizeInput($data['token']);

try {
    $pdo = getDbConnection();
    
    // Delete session
    $stmt = $pdo->prepare("DELETE FROM user_sessions WHERE session_token = :token");
    $stmt->execute(['token' => $token]);
    
    respondWithSuccess([
        'message' => 'Logged out successfully'
    ], 200);
    
} catch (PDOException $e) {
    respondWithError('Logout failed: ' . $e->getMessage(), 500);
}

?>
