<?php
/**
 * Forgot Password API Endpoint
 * Handles password reset token generation and email sending
 */

require_once '../db_connect.php';
require_once '../mail_helper.php';

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respondWithError('Method not allowed. Use POST', 405);
}

// Get JSON input
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Validate required fields
$validation = validateRequiredFields($data, ['email']);
if ($validation !== true) {
    respondWithError($validation, 400);
}

// Sanitize input
$email = sanitizeInput($data['email']);

// Validate email format
if (!isValidEmail($email)) {
    respondWithError('Invalid email format', 400);
}

try {
    $pdo = getDbConnection();
    
    // Check if user exists
    $stmt = $pdo->prepare("SELECT id, full_name, email FROM users WHERE email = :email");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch();
    
    // For security, don't reveal if email exists or not
    // Always return success message
    if ($user) {
        // Generate reset token (shorter for email - 6 characters)
        $resetToken = strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
        $expiresAt = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        // Invalidate old tokens for this user
        $invalidateStmt = $pdo->prepare("
            UPDATE password_reset_tokens 
            SET is_used = TRUE 
            WHERE user_id = :user_id AND is_used = FALSE
        ");
        $invalidateStmt->execute(['user_id' => $user['id']]);
        
        // Store reset token
        $tokenStmt = $pdo->prepare("
            INSERT INTO password_reset_tokens (user_id, token, expires_at) 
            VALUES (:user_id, :token, :expires_at)
        ");
        $tokenStmt->execute([
            'user_id' => $user['id'],
            'token' => $resetToken,
            'expires_at' => $expiresAt
        ]);
        
        // Send password reset email
        $emailResult = sendPasswordResetEmail(
            $user['email'],
            $user['full_name'] ?? 'User',
            $resetToken,
            '1 hour'
        );
        
        if (!$emailResult['success']) {
            // Log email error but don't expose to user for security
            error_log("Email sending failed: " . $emailResult['message']);
        }
        
        $response = [
            'message' => 'Password reset instructions sent to your email',
            'expires_in' => '1 hour',
            'email_sent' => $emailResult['success']
        ];
    } else {
        // Still return success to prevent email enumeration
        $response = [
            'message' => 'Password reset instructions sent to your email'
        ];
    }
    
    respondWithSuccess($response, 200);
    
} catch (PDOException $e) {
    respondWithError('Failed to process request: ' . $e->getMessage(), 500);
}

?>
