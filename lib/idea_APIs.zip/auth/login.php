<?php
/**
 * Login API Endpoint
 * Handles user authentication
 */

require_once '../db_connect.php';

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respondWithError('Method not allowed. Use POST', 405);
}

// Get JSON input
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Validate required fields
$validation = validateRequiredFields($data, ['email', 'password']);
if ($validation !== true) {
    respondWithError($validation, 400);
}

// Sanitize inputs
$email = sanitizeInput($data['email']);
$password = $data['password']; // Don't sanitize password

// Validate email format
if (!isValidEmail($email)) {
    respondWithError('Invalid email format', 400);
}

try {
    $pdo = getDbConnection();
    
    // Get user by email
    $stmt = $pdo->prepare("
        SELECT id, full_name, email, password, user_type, is_active, email_verified 
        FROM users 
        WHERE email = :email
    ");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch();
    
    // Check if user exists
    if (!$user) {
        respondWithError('Invalid email or password', 401);
    }
    
    // Check if user is active
    if (!$user['is_active']) {
        respondWithError('Account is deactivated. Please contact support', 403);
    }
    
    // Verify password
    if (!verifyPassword($password, $user['password'])) {
        respondWithError('Invalid email or password', 401);
    }
    
    // Update last login
    $updateStmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = :id");
    $updateStmt->execute(['id' => $user['id']]);
    
    // Generate session token
    $sessionToken = generateToken(32);
    $expiresAt = date('Y-m-d H:i:s', strtotime('+7 days'));
    
    // Store session
    $sessionStmt = $pdo->prepare("
        INSERT INTO user_sessions (user_id, session_token, ip_address, user_agent, expires_at) 
        VALUES (:user_id, :token, :ip, :user_agent, :expires_at)
    ");
    $sessionStmt->execute([
        'user_id' => $user['id'],
        'token' => $sessionToken,
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
        'expires_at' => $expiresAt
    ]);
    
    // Prepare response (exclude password)
    $response = [
        'user' => [
            'id' => $user['id'],
            'full_name' => $user['full_name'],
            'email' => $user['email'],
            'user_type' => $user['user_type'],
            'email_verified' => (bool)$user['email_verified']
        ],
        'token' => $sessionToken,
        'expires_at' => $expiresAt
    ];
    
    respondWithSuccess($response, 200);
    
} catch (PDOException $e) {
    respondWithError('Login failed: ' . $e->getMessage(), 500);
}

?>
