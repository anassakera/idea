<?php
/**
 * Mail Helper - Email Sending Functions using PHPMailer
 * 
 * Prerequisites:
 * 1. Install PHPMailer: composer require phpmailer/phpmailer
 * 2. Configure smtp_config.php with your Gmail App Password
 */

require_once __DIR__ . '/smtp_config.php';

// Include PHPMailer classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Autoload PHPMailer (via Composer)
$composerAutoload = __DIR__ . '/vendor/autoload.php';
if (file_exists($composerAutoload)) {
    require_once $composerAutoload;
}

/**
 * Send password reset email
 * 
 * @param string $toEmail Recipient email address
 * @param string $toName Recipient name
 * @param string $resetToken Password reset token
 * @param string $expiresIn Token expiration time (e.g., "1 hour")
 * @return array ['success' => bool, 'message' => string]
 */
function sendPasswordResetEmail($toEmail, $toName, $resetToken, $expiresIn = '1 hour') {
    // Check if PHPMailer is available
    if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) {
        return [
            'success' => false,
            'message' => 'PHPMailer is not installed. Run: composer require phpmailer/phpmailer'
        ];
    }

    $mail = new PHPMailer(true);

    try {
        // Server settings
        if (SMTP_DEBUG) {
            $mail->SMTPDebug = SMTP::DEBUG_SERVER;
        }
        $mail->isSMTP();
        $mail->Host = SMTP_HOST;
        $mail->SMTPAuth = true;
        $mail->Username = SMTP_USERNAME;
        $mail->Password = SMTP_PASSWORD;
        $mail->SMTPSecure = SMTP_SECURE;
        $mail->Port = SMTP_PORT;
        $mail->CharSet = 'UTF-8';

        // Recipients
        $mail->setFrom(SMTP_FROM_EMAIL, SMTP_FROM_NAME);
        $mail->addAddress($toEmail, $toName);
        $mail->addReplyTo(SMTP_FROM_EMAIL, SMTP_FROM_NAME);

        // Content
        $mail->isHTML(true);
        $mail->Subject = APP_NAME . ' - Password Reset Request';
        
        // Build HTML email body
        $htmlBody = buildPasswordResetEmailHTML($toName, $resetToken, $expiresIn);
        $mail->Body = $htmlBody;
        
        // Plain text alternative
        $mail->AltBody = buildPasswordResetEmailText($toName, $resetToken, $expiresIn);

        $mail->send();
        
        return [
            'success' => true,
            'message' => 'Password reset email sent successfully'
        ];
        
    } catch (Exception $e) {
        return [
            'success' => false,
            'message' => 'Email could not be sent. Error: ' . $mail->ErrorInfo
        ];
    }
}

/**
 * Build HTML email body for password reset
 */
function buildPasswordResetEmailHTML($name, $resetToken, $expiresIn) {
    $appName = APP_NAME;
    
    return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Reset</title>
</head>
<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f4f4;">
    <table role="presentation" style="width: 100%; border-collapse: collapse;">
        <tr>
            <td align="center" style="padding: 40px 0;">
                <table role="presentation" style="width: 600px; border-collapse: collapse; background-color: #ffffff; border-radius: 10px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
                    <!-- Header -->
                    <tr>
                        <td style="padding: 40px 30px; text-align: center; background: linear-gradient(135deg, #525CEB 0%, #3D3B40 100%); border-radius: 10px 10px 0 0;">
                            <h1 style="color: #ffffff; margin: 0; font-size: 28px;">{$appName}</h1>
                            <p style="color: rgba(255,255,255,0.9); margin: 10px 0 0 0; font-size: 14px;">Password Reset Request</p>
                        </td>
                    </tr>
                    
                    <!-- Content -->
                    <tr>
                        <td style="padding: 40px 30px;">
                            <h2 style="color: #333333; margin: 0 0 20px 0; font-size: 22px;">Hello, {$name}!</h2>
                            <p style="color: #666666; font-size: 16px; line-height: 1.6; margin: 0 0 20px 0;">
                                We received a request to reset your password. Use the code below to reset your password:
                            </p>
                            
                            <!-- Reset Code Box -->
                            <div style="background-color: #f8f9fa; border: 2px dashed #525CEB; border-radius: 8px; padding: 25px; text-align: center; margin: 30px 0;">
                                <p style="color: #666666; font-size: 14px; margin: 0 0 10px 0;">Your Reset Code:</p>
                                <h1 style="color: #525CEB; margin: 0; font-size: 32px; letter-spacing: 4px; font-family: monospace;">{$resetToken}</h1>
                            </div>
                            
                            <p style="color: #666666; font-size: 14px; line-height: 1.6; margin: 20px 0;">
                                <strong>⏰ This code expires in {$expiresIn}.</strong>
                            </p>
                            
                            <p style="color: #999999; font-size: 14px; line-height: 1.6; margin: 20px 0 0 0;">
                                If you didn't request this password reset, please ignore this email. Your password will remain unchanged.
                            </p>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="padding: 30px; text-align: center; background-color: #f8f9fa; border-radius: 0 0 10px 10px;">
                            <p style="color: #999999; font-size: 12px; margin: 0;">
                                © 2024 {$appName}. All rights reserved.
                            </p>
                            <p style="color: #999999; font-size: 12px; margin: 10px 0 0 0;">
                                This is an automated message, please do not reply.
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
HTML;
}

/**
 * Build plain text email body for password reset
 */
function buildPasswordResetEmailText($name, $resetToken, $expiresIn) {
    $appName = APP_NAME;
    
    return <<<TEXT
{$appName} - Password Reset Request

Hello, {$name}!

We received a request to reset your password. Use the code below to reset your password:

Your Reset Code: {$resetToken}

This code expires in {$expiresIn}.

If you didn't request this password reset, please ignore this email. Your password will remain unchanged.

---
© 2024 {$appName}. All rights reserved.
This is an automated message, please do not reply.
TEXT;
}

?>
